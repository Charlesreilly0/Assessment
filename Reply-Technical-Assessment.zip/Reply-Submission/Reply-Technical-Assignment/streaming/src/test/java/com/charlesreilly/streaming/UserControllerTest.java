package com.charlesreilly.streaming;

import com.charlesreilly.streaming.User.User;
import com.charlesreilly.streaming.User.UserController;
import com.charlesreilly.streaming.User.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateUser_Success() {
        User user = mock(User.class);
        when(user.basicValidationChecks()).thenReturn(true);
        when(user.isOfAge()).thenReturn(true);
        when(user.getUsername()).thenReturn("FriedrichGauss");
        when(userService.getUserByUsername("FriedrichGauss")).thenReturn(null);

        ResponseEntity<String> response = userController.createUser(user);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("User created successfully", response.getBody());
    }

    @Test
    public void createUser_ShouldReturnHTTP400_WhenBasicValidationFails() {
        User user = mock(User.class);
        when(user.basicValidationChecks()).thenReturn(false);

        ResponseEntity<String> response = userController.createUser(user);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Failed Basic Validation Checks", response.getBody());
    }

    @Test
    public void createUser_ShouldReturnHTTP403_WhenUserIsUnderage() {
        User user = mock(User.class);
        when(user.basicValidationChecks()).thenReturn(true);
        when(user.isOfAge()).thenReturn(false);

        ResponseEntity<String> response = userController.createUser(user);

        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertEquals("User Is Underage", response.getBody());
    }

    @Test
    public void createUser_ShouldReturnHTTP409_WhenUserIsAlreadyRegistered() {
        User user = mock(User.class);
        when(user.basicValidationChecks()).thenReturn(true);
        when(user.isOfAge()).thenReturn(true);
        when(user.getUsername()).thenReturn("CharlesReilly");
        when(userService.getUserByUsername("CharlesReilly")).thenReturn(new User(
                        "CharlesReilly",
                        "Password123",
                        "c.reilly@gmail.com",
                        LocalDate.of(1777,4,30),
                        "1234567812345678"
        ));

        ResponseEntity<String> response = userController.createUser(user);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals("User Already Exists", response.getBody());
    }


    @Test
    public void getUsers_ShouldReturnAllUsers_WhenNoFilter() {
        List<User> mockUsers = new ArrayList<>();
        when(userService.getAllUsers()).thenReturn(mockUsers);

        ResponseEntity<Collection<User>> response = userController.getUsers(null);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockUsers, response.getBody());
    }

    @Test
    public void getUsers_ShouldReturnAllUsersWithCreditCard_WhenFilterIsYes() {
        List<User> mockUsers = new ArrayList<>();
        when(userService.getUsersByCreditCardFilter(true)).thenReturn(mockUsers);

        ResponseEntity<Collection<User>> response = userController.getUsers("Yes");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockUsers, response.getBody());
    }

    @Test
    public void getUsers_ShouldReturnAllUsersWithNoCreditCard_WhenFilterIsNo() {
        List<User> mockUsers = new ArrayList<>();
        when(userService.getUsersByCreditCardFilter(false)).thenReturn(mockUsers);

        ResponseEntity<Collection<User>> response = userController.getUsers("No");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockUsers, response.getBody());
    }
}
