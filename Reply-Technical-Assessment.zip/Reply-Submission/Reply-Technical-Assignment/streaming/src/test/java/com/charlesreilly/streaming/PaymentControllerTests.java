package com.charlesreilly.streaming;

import com.charlesreilly.streaming.Payment.Payment;
import com.charlesreilly.streaming.Payment.PaymentController;
import com.charlesreilly.streaming.Payment.PaymentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class PaymentControllerTest {

    @Mock
    private PaymentService paymentService;

    @InjectMocks
    private PaymentController paymentController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void processPayment_ShouldReturn201_WhenPaymentIsSuccessful() {
        Payment payment = new Payment("1234567812345678", "100");

        when(paymentService.processPayment(payment)).thenReturn(true);

        ResponseEntity<String> response = paymentController.processPayment(payment);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Payment processed successfully", response.getBody());
    }

    @Test
    void processPayment_ShouldReturn404_WhenCreditCardNotRegistered() {
        Payment payment = new Payment("1234567812345678", "100");

        when(paymentService.processPayment(payment)).thenReturn(false);

        ResponseEntity<String> response = paymentController.processPayment(payment);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("Credit card not registered", response.getBody());
    }

    @Test
    void processPayment_ShouldReturn400_WhenPaymentDataIsInvalid() {
        Payment payment = new Payment("123", "10");

        ResponseEntity<String> response = paymentController.processPayment(payment);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Invalid credit card number", response.getBody());
    }
}
