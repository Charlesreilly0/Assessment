package com.charlesreilly.streaming;

import com.charlesreilly.streaming.Payment.Payment;
import com.charlesreilly.streaming.Payment.PaymentService;
import com.charlesreilly.streaming.User.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PaymentServiceTests {
    @Mock
    private UserService userService;

    @InjectMocks
    private PaymentService paymentService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void processPayment_ShouldReturnTrue_WhenCreditCardIsRegistered() {
        Payment payment = new Payment("1234567812345678", "100");

        when(userService.isCreditCardRegistered("1234567812345678")).thenReturn(true);

        boolean result = paymentService.processPayment(payment);

        assertTrue(result);
        verify(userService, times(1)).isCreditCardRegistered("1234567812345678");
    }

    @Test
    void processPayment_ShouldReturnFalse_WhenCreditCardIsNotRegistered() {
        Payment payment = new Payment("1234567812345678", "100");

        when(userService.isCreditCardRegistered("1234567812345678")).thenReturn(false);

        boolean result = paymentService.processPayment(payment);

        assertFalse(result);
        verify(userService, times(1)).isCreditCardRegistered("1234567812345678");
    }

    @Test
    void processPayment_ShouldThrowException_WhenPaymentDataIsInvalid() {
        Payment payment = new Payment("123", "10"); // Invalid data

        assertThrows(IllegalArgumentException.class, () -> paymentService.processPayment(payment));
    }
}
