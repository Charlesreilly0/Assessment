package com.charlesreilly.streaming;

import com.charlesreilly.streaming.User.User;
import com.charlesreilly.streaming.User.UserController;
import com.charlesreilly.streaming.User.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createUser_ShouldAddUser_WhenUserDataIsValid() {
        User user = mock(User.class);

        // Set up the mock behavior
        when(user.getUsername()).thenReturn("CharlesReilly");

        when(userService.getUserByUsername("CharlesReilly")).thenReturn(null);

        doAnswer(invocation -> {
            when(userService.getUserByUsername("CharlesReilly")).thenReturn(user);
            return null;
        }).when(userService).createUser(user);

        userService.createUser(user);

        verify(userService, times(1)).createUser(user);

        assertNotNull(userService.getUserByUsername("CharlesReilly"));
    }



    @Test
    void isCreditCardRegistered_ShouldReturnTrue_WhenCreditCardIsRegistered() {
        User user = mock(User.class);
        when(user.getCardNumber()).thenReturn("1234567812345678");

        when(userService.getUserByUsername("CharlesReilly")).thenReturn(null);
        when(userService.isCreditCardRegistered("1234567812345678")).thenReturn(true);

        userService.createUser(user);

        assertTrue(userService.isCreditCardRegistered("1234567812345678"));
    }


    @Test
    void isCreditCardRegistered_ShouldReturnFalse_WhenCreditCardIsNotRegistered() {
        // Mock behavior for isCreditCardRegistered
        when(userService.isCreditCardRegistered("1234567812345678")).thenReturn(false);

        // Assert that the credit card is not registered
        assertFalse(userService.isCreditCardRegistered("1234567812345678"));
    }
}
