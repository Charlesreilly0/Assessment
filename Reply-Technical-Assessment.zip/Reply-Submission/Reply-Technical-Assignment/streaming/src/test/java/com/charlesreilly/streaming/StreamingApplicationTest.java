package com.charlesreilly.streaming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamingApplicationTest {

	@Test
	void contextLoads() {
	}

}
