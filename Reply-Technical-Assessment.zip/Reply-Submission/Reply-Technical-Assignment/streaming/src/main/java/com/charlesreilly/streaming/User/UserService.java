package com.charlesreilly.streaming.User;

import org.springframework.stereotype.Service;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final Map<String, User> userStore = new ConcurrentHashMap<>();

    public void createUser(User user) {
        if (!user.basicValidationChecks()) {
            throw new IllegalArgumentException("Invalid user data");
        }

        if (userStore.containsKey(user.getUsername())) {
            throw new IllegalArgumentException("Username already exists");
        }

        userStore.put(user.getUsername(), user);
    }

    public Collection<User> getAllUsers() {
        return userStore.values();
    }

    public Collection<User> getUsersByCreditCardFilter(boolean hasCreditCard) {
        return userStore.values().stream()
                .filter(user -> user.hasCreditCard() == hasCreditCard)
                .collect(Collectors.toList());
    }


    public boolean isCreditCardRegistered(String creditCardNumber) {
        return userStore.values().stream()
                .anyMatch(user -> creditCardNumber.equals(user.getCardNumber()));
    }

    public Object getUserByUsername(String username) {
        return userStore.get(username);
    }
}
