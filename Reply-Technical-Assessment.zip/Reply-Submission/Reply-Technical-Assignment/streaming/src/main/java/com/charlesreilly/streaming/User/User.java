package com.charlesreilly.streaming.User;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.time.LocalDate;
import java.time.Period;

public class User {
    private String username;
    private String password;
    private String emailAddress;
    private LocalDate dob;
    private String cardNumber = null;


    private static final String PASSWORD_REGEX = "^(?=.*[A-Z])(?=.*\\d).{8,}$";
    private static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
    private static final String USERNAME_REGEX = "^[a-zA-Z0-9]+$";
    private static final String CREDIT_CARD_REGEX = "^\\d{16}$";

    public User(String username, String password, String emailAddress, LocalDate dob, String cardNumber) {
        if(!validateUsername(username)){
            throw new IllegalArgumentException("Username doesn't contain only alphanumeric characters and/or contains spaces");
        }
        if(!validatePassword(password)){
            throw new IllegalArgumentException("Password fails complexity requirements");
        }
        if(!validateEmailAddress(emailAddress)){
            throw new IllegalArgumentException("Email address is not valid");
        }
        if(!validateDOB(dob)){
            throw new IllegalArgumentException("DOB doesn't match ISO-8061 standards");
        }
        if(cardNumber != null && !validateCreditCardNumber(cardNumber)){
            throw new IllegalArgumentException("Credit card number must only contain 16 digits");
        }
        this.username = username;
        this.password = password;
        this.emailAddress = emailAddress;
        this.dob = dob;
        this.cardNumber = cardNumber;
    }

    public Boolean validateCreditCardNumber(String cardNumber) {
        return cardNumber != null && cardNumber.matches(CREDIT_CARD_REGEX);
    }

    public Boolean validateEmailAddress(String emailAddress) {
        return emailAddress != null &&  emailAddress.matches(EMAIL_REGEX);
    }

    public Boolean validatePassword(String password) {
        return password != null && password.matches(PASSWORD_REGEX);
    }

    public Boolean validateUsername(String username) {
        return username != null && username.matches(USERNAME_REGEX);
    }

    public Boolean validateDOB(LocalDate dob) {
        return dob != null;
    }

    public Boolean basicValidationChecks(){
        return validateUsername(username) &&
                validatePassword(password) &&
                validateEmailAddress(emailAddress) &&
                validateDOB(dob);
    }

    @JsonIgnore
    public boolean isOfAge(){
        return Period.between(dob,LocalDate.now()).getYears() >= 18;
    }

    public boolean hasCreditCard() {
        return cardNumber != null;
    }

    public String getUsername() {
        return username;
    }


    public String getPassword() {
        return password;
    }


    public String getEmailAddress() {
        return emailAddress;
    }


    public String getCardNumber() {
        return cardNumber;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }
}