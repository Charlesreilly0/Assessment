package com.charlesreilly.streaming.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<String> createUser(@RequestBody User user) {
        if (!user.basicValidationChecks()) {
            return new ResponseEntity<>("Failed Basic Validation Checks", HttpStatus.BAD_REQUEST); // Returns HTTP 400
        }
        if (!user.isOfAge()) {
            return new ResponseEntity<>("User Is Underage", HttpStatus.FORBIDDEN); // Returns HTTP 403
        }
        if (userService.getUserByUsername(user.getUsername()) != null) {
            return new ResponseEntity<>("User Already Exists", HttpStatus.CONFLICT); // Returns HTTP 409
        }

        try {
            userService.createUser(user);
            return new ResponseEntity<>("User created successfully", HttpStatus.CREATED); // Returns HTTP 201
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }


    @GetMapping
    public ResponseEntity<Collection<User>> getUsers(@RequestParam(value = "CreditCard", required = false) String creditCardFilter) {
        Collection<User> users;

        if ("Yes".equalsIgnoreCase(creditCardFilter)) {
            users = userService.getUsersByCreditCardFilter(true);
        } else if ("No".equalsIgnoreCase(creditCardFilter)) {
            users = userService.getUsersByCreditCardFilter(false);
        } else {
            users = userService.getAllUsers();
        }

        return new ResponseEntity<>(users, HttpStatus.OK);
    }

}
