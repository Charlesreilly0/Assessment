package com.charlesreilly.streaming.Payment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    @Autowired
    public PaymentService paymentService;

    @PostMapping
    public ResponseEntity<String> processPayment(@RequestBody Payment payment) {
        // Validate payment details
        if (payment.getCardNumber() == null || !payment.validateCreditCardNumber(payment.getCardNumber())) {
            return new ResponseEntity<>("Invalid credit card number", HttpStatus.BAD_REQUEST);
        }
        if (payment.getAmount() == null || !payment.validateAmount(payment.getAmount())) {
            return new ResponseEntity<>("Invalid amount", HttpStatus.BAD_REQUEST);
        }

        // Check if the credit card is registered
        boolean isRegistered = paymentService.processPayment(payment);
        if (!isRegistered) {
            return new ResponseEntity<>("Credit card not registered", HttpStatus.NOT_FOUND);
        }

        // Process payment successfully
        return new ResponseEntity<>("Payment processed successfully", HttpStatus.CREATED);
    }
}
