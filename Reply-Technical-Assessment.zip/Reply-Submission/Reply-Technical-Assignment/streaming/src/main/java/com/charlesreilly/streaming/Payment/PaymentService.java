package com.charlesreilly.streaming.Payment;

import com.charlesreilly.streaming.User.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    @Autowired
    public UserService userService;

    public boolean processPayment(Payment payment) {
        // Validate payment data
        if (payment.getCardNumber() == null || payment.getAmount() == null) {
            throw new IllegalArgumentException("Invalid payment data");
        }

        // Check if the credit card is associated with a registered user
        return userService.isCreditCardRegistered(payment.getCardNumber());
    }
}
