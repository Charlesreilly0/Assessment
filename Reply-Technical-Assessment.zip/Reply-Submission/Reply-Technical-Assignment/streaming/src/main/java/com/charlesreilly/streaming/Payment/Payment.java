package com.charlesreilly.streaming.Payment;

public class Payment {
    private String cardNumber;
    private String amount;

    private static final String CREDIT_CARD_REGEX = "^\\d{16}$";
    private static final String AMOUNT_REGEX = "^\\d{3}$";

    public Payment(String cardNumber, String amount) {
        this.cardNumber = validateCreditCardNumber(cardNumber) ? cardNumber : null;
        this.amount = validateAmount(amount) ? amount : null;
    }

    public boolean validateCreditCardNumber(String creditCardNumber) {
        return creditCardNumber != null && creditCardNumber.matches(CREDIT_CARD_REGEX);
    }

    public boolean validateAmount(String amount) {
        return amount != null && amount.matches(AMOUNT_REGEX);
    }

    // Getters and setters
    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
