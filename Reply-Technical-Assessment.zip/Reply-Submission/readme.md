For clear and formatted instructions, use the following link: https://github.com/Charlesreilly0/Assessment/tree/main
